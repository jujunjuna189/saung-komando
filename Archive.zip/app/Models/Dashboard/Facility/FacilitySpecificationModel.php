<?php

namespace App\Models\Dashboard\Facility;

use Illuminate\Database\Eloquent\Model;

class FacilitySpecificationModel extends Model
{
    protected $table = 'facility_specification';
    protected $guarded = ['id'];
}
