<?php

namespace App\Models\Dashboard\Facility;

use Illuminate\Database\Eloquent\Model;

class FacilityThumbnailModel extends Model
{
    protected $table = 'facility_thumbnails';
    protected $guarded = ['id'];
}
