<?php

namespace App\Models\Dashboard\Facility;

use Illuminate\Database\Eloquent\Model;

class FacilityCategoryModel extends Model
{
    protected $table = 'facility_category';
    protected $guarded = ['id'];
}
