<?php

namespace App\Models\Dashboard\Gallery;

use Illuminate\Database\Eloquent\Model;

class GalleryModel extends Model
{
    //
}
