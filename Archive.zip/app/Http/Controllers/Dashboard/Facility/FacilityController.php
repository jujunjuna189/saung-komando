<?php

namespace App\Http\Controllers\Dashboard\Facility;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class FacilityController extends Controller
{
    //
}
