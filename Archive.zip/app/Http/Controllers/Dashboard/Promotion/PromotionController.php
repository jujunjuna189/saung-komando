<?php

namespace App\Http\Controllers\Dashboard\Promotion;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class PromotionController extends Controller
{
    //
}
