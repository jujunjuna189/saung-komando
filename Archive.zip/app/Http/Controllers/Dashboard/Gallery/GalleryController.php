<?php

namespace App\Http\Controllers\Dashboard\Gallery;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class GalleryController extends Controller
{
    public function show() {}
    public function create() {}
    public function update() {}
    public function delete() {}
}
