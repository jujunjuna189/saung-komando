<?php

namespace App\Http\Controllers\Public\Promotion;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class PromotionController extends Controller
{
    //
}
